import GLib from "gi://GLib";
import Gio from "gi://Gio";
const DEFAULT_CONFIG = `# App Shortcuts
# Apps
launch f9 firefox-esr
launch f10 code
launch f11 alacritty

# Window Management
win_prev f4
win_other f12
win_delete 3
win_center_mouse
`;
export default class Config {
    entries;
    constructor() {
        const file = this._getConfigFile();
        this.entries = this._createConfigMap(file);
    }
    _getConfigFile() {
        const configDir = `${GLib.get_home_dir()}/.config/glaunchv2`;
        const file = Gio.File.new_for_path(`${configDir}/glaunch.conf`);
        if (!file.query_exists(null)) {
            const success = this._createConfigFile(configDir, file);
            if (!success) {
                throw new Error("[GlaunchV2] Error config file");
            }
        }
        return file;
    }
    _createConfigMap(file) {
        const [success, contents] = file.load_contents(null);
        if (!success) {
            throw new Error("[GlaunchV2] Error Loading config file");
        }
        const config = [];
        const configurationLines = new TextDecoder("utf-8").decode(contents);
        configurationLines.split("\n").forEach((line, lineNumber) => {
            if (line.trim() === "" || line.trim().startsWith("#")) {
                return;
            }
            const parts = line.trim().split(/\s+/);
            if (parts.length === 1) {
                config.push({
                    act: parts[0],
                });
            }
            else if (parts.length === 2) {
                config.push({
                    act: parts[0],
                    key: parts[1],
                });
            }
            else if (parts.length === 3) {
                config.push({
                    act: parts[0],
                    key: parts[1],
                    app: parts[2],
                });
            }
            else {
                console.warn(`[GlaunchV2] Ignoring malformed config line ${lineNumber + 1}`);
            }
        });
        return config;
    }
    _createConfigFile(configDir, file) {
        let outputStream = null;
        try {
            const dir = Gio.File.new_for_path(configDir);
            if (!dir.query_exists(null)) {
                dir.make_directory_with_parents(null);
            }
            outputStream = file.create(Gio.FileCreateFlags.NONE, null);
            const bytes = new TextEncoder().encode(DEFAULT_CONFIG);
            outputStream.write_bytes(bytes, null);
            return true;
        }
        catch (error) {
            throw new Error(`[GlaunchV2] Error creating config file: ${error}`);
        }
        finally {
            if (outputStream) {
                try {
                    outputStream.close(null);
                }
                catch (closeError) {
                    console.error(`[GlaunchV2] Error closing output stream: ${closeError}`);
                }
            }
        }
    }
}
