import * as Main from "resource:///org/gnome/shell/ui/main.js";
import Gio from "gi://Gio";
import Meta from "gi://Meta";
import Shell from "gi://Shell";
import { App, AppCollection } from "./apps.js";
export default class Launcher {
    _config;
    _settings;
    _apps = new Map();
    _other = "other";
    constructor(config, settings) {
        this._config = config;
        this._settings = settings;
        this._bindKeys();
    }
    storeApp(win) {
        if (!win) {
            return;
        }
        let appName = win?.get_wm_class()?.toLowerCase().replace(/[0-9]/g, '') ?? "";
        if (appName === "" || appName === "gjs")
            return;
        if (win.window_type !== Meta.WindowType.NORMAL)
            return;
        const mapName = Gio.DesktopAppInfo?.search(appName)[0][0];
        if (this._apps.has(mapName)) {
            console.warn(`[GlaunchV2:2-0] Storing new app in existing mapping ${mapName}`);
            this._apps.get(mapName)?.storeApp(win);
        }
        else {
            console.warn(`[GlaunchV2:2.1] Storing new app in old mapping ${mapName}`);
            const app = new App(win);
            this._apps.set(mapName, new AppCollection(app));
        }
    }
    deleteApp(win) {
        if (!win) {
            return;
        }
        let appName = win?.get_wm_class() ?? "";
        if (!this._config.boundedApps.has(appName)) {
            appName = this._other;
        }
        if (this._apps.has(appName)) {
            const appCol = this._apps.get(appName);
            appCol?.deleteApp(win);
            if (appCol?.size() == 0) {
                this._apps.delete(appName);
            }
        }
    }
    _handleApp(appName) {
        if (!appName) {
            return;
        }
        const focusedWin = global.display.focus_window;
        const focusedName = focusedWin?.get_wm_class()?.toLowerCase().replace(/[0-9]/g, '') ?? "";
        const focusedFile = Gio.DesktopAppInfo.search(focusedName)[0][0];
        const desktopFile = appName + ".desktop";
        if (desktopFile === focusedFile && this._apps.has(appName)) {
            this._apps.get(appName)?.goNext();
        }
        else if (this._apps.has(appName)) {
            console.warn(`[GlaunchV2:1.0] switching to map app ${focusedName}`);
            this._apps.get(appName)?.switchToApp();
        }
        else {
            console.warn(`[GlaunchV2:1.1] Adding new map app ${focusedName}`);
            Gio.DesktopAppInfo.new(desktopFile)?.launch([], null);
        }
    }
    _goToPrev() {
        const windows = global.display.get_tab_list(Meta.TabList.NORMAL, null);
        if (windows.length < 2) {
            return;
        }
        new App(windows[1]).focus();
    }
    _bindKeys() {
        this._config.entries.forEach((bind, _) => {
            switch (bind.act) {
                case "launch":
                    Main.wm.addKeybinding(bind.key, this._settings, Meta.KeyBindingFlags.NONE, Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW, () => this._handleApp(bind.app));
                    break;
                case "win_prev":
                    Main.wm.addKeybinding(bind.key, this._settings, Meta.KeyBindingFlags.NONE, Shell.ActionMode.NORMAL | Shell.ActionMode.OVERVIEW, () => this._goToPrev());
                    break;
            }
        });
    }
}
