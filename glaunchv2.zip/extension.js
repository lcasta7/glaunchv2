import * as Main from "resource:///org/gnome/shell/ui/main.js";
import { Extension } from "resource:///org/gnome/shell/extensions/extension.js";
import Config from "./config.js";
import Launcher from "./launcher.js";
export default class GlaunchV2 extends Extension {
    _config = new Config();
    _settings = null;
    enable() {
        this._settings = this.getSettings("org.gnome.shell.extensions.glaunchv2");
        const launcher = new Launcher(this._config, this._settings);
        global.window_manager.connect("map", (_, win) => {
            launcher.storeApp(win.get_meta_window());
        });
        global.window_manager.connect("destroy", (_, win) => {
            launcher.deleteApp(win.get_meta_window());
        });
    }
    disable() {
        this._config.entries.forEach((bind, _) => {
            Main.wm.removeKeybinding(bind.key);
        });
        if (this._settings) {
            this._settings.run_dispose();
            this._settings = null;
        }
    }
}
