import { Extension } from "resource:///org/gnome/shell/extensions/extension.js";
import Config from "./config.js";
import Launcher from "./launcher.js";
export default class GlaunchV2 extends Extension {
    enable() {
        const config = new Config();
        const settings = this.getSettings("org.gnome.shell.extensions.glaunchv2");
        const launcher = new Launcher(config, settings);
        global.window_manager.connect("map", (_, win) => {
            launcher.storeApp(win?.get_meta_window());
        });
        global.window_manager.connect("destroy", (_, win) => {
            launcher.deleteApp(win?.get_meta_window());
        });
    }
    disable() { }
}
