import { Extension } from 'resource:///org/gnome/shell/extensions/extension.js';
export default class GlaunchV2 extends Extension {
    enable() {
        global.window_manager.connect('map', (_, win) => {
            console.log('GlaunchV2: sucessfully logged: ', win.get_meta_window()?.get_wm_class());
        });
    }
    disable() {
    }
}
// global.window_manager.connect('map', (_, actor) => {
// 	let metaWindow = actor.meta_window;
// 	this._storeApp(metaWindow);
// });
