import Clutter from 'gi://Clutter';
export class AppCollection {
    _head;
    _col;
    _hIndex = 0;
    constructor(app) {
        this._head = app;
        this._col = [app];
    }
    goNext() {
        this._hIndex = (this._hIndex + 1) % this._col.length;
        this._head = this._col[this._hIndex];
        this._head.focus();
    }
    storeApp(win) {
        const app = new App(win);
        this._col.push(app);
        this._head = app;
        app.focus();
    }
    size() {
        return this._col.length;
    }
    deleteApp(win) {
        const index = this._col.findIndex(w => w.equals(win));
        if (index === -1) {
            return;
        }
        this._col.splice(index, 1);
    }
    switchToApp() {
        this._head.focus();
    }
}
export class App {
    _win;
    constructor(win) {
        this._win = win;
    }
    focus() {
        this._win.raise_and_make_recent_on_workspace(this._win.get_workspace());
        this._centerMouse();
        this._win.focus(global.get_current_time());
    }
    equals(win) {
        return win === this._win;
    }
    _centerMouse() {
        let rect = this._win.get_frame_rect();
        let x = rect.x + rect.width / 2;
        let y = rect.y + rect.height / 2;
        let seat = Clutter.get_default_backend().get_default_seat();
        seat.warp_pointer(x, y);
    }
}
