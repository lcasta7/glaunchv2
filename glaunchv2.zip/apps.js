import Clutter from 'gi://Clutter';
export class AppCollection {
    _head;
    _col;
    _hIndex = 0;
    _centerMouse;
    constructor(app, centerMouse) {
        this._head = app;
        this._col = [app];
        this._centerMouse = centerMouse;
    }
    goNext() {
        this._hIndex = (this._hIndex + 1) % this._col.length;
        this._head = this._col[this._hIndex];
        this._head.focus(this._centerMouse);
    }
    switchToApp() {
        if (!this._head) {
            console.warn('[GlaunchV2] Cannot switch to app: head is not defined');
            return;
        }
        this._head.focus(this._centerMouse);
    }
    storeApp(win) {
        if (!win || !win.is_alive) {
            console.warn('[GlaunchV2] Attempted to store an invalid window');
            return;
        }
        const index = this._col.findIndex(app => app.equals(win));
        if (index !== -1) {
            console.log(`[GlaunchV2] Window already exists in collection, switching to it instead of creating duplicate`);
            this._hIndex = index;
            this._head = this._col[this._hIndex];
            this._head.focus(this._centerMouse);
            return;
        }
        const app = new App(win);
        this._col.push(app);
        this._hIndex = this._col.length - 1;
        this._head = app;
        this._head.focus(this._centerMouse);
    }
    deleteApp(win) {
        if (!win) {
            console.warn('[GlaunchV2] Attempted to delete an invalid window');
            return;
        }
        const index = this._col.findIndex(w => w.equals(win));
        if (index === -1) {
            return;
        }
        this._col.splice(index, 1);
        if (this._col.length === 0) {
            this._hIndex = 0;
            return;
        }
        if (index <= this._hIndex) {
            this._hIndex = Math.max(0, this._hIndex - 1);
        }
        this._head = this._col[this._hIndex];
    }
    size() {
        return this._col.length;
    }
}
export class App {
    _win;
    constructor(win) {
        this._win = win;
    }
    focus(centerMouse) {
        if (!this._win || !this._win.is_alive) {
            console.warn('[GlaunchV2] Cannot focus: window is not valid');
            return;
        }
        this._win.raise_and_make_recent_on_workspace(this._win.get_workspace());
        if (centerMouse) {
            this._centerMouse();
        }
        this._win.focus(global.get_current_time());
    }
    equals(win) {
        return win === this._win;
    }
    _centerMouse() {
        if (!this._win || !this._win.is_alive) {
            return;
        }
        const rect = this._win.get_frame_rect();
        const x = rect.x + rect.width / 2;
        const y = rect.y + rect.height / 2;
        const seat = Clutter.get_default_backend().get_default_seat();
        seat.warp_pointer(x, y);
    }
}
